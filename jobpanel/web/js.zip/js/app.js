// ===== Elias Developments - Modern Job Panel =====
// ===== Version 2.1 - Fixed =====

// ===== Global State =====
let panelData = {
    job: '',
    grade: 0,
    permissions: {},
    employees: [],
    ranks: [],
    finances: {
        balance: 0,
        transactions: []
    },
    vehicles: [],
    items: [],
    logs: [],
    branding: {
        title: 'Elias Developments',
        subtitle: 'Job Management System'
    }
};

let cart = [];
let selectedPlayer = null;
let currentMoneyAction = null;
let confirmCallback = null;
let currentTheme = 'dark';
let isLoading = false;

// ===== Initialization =====
document.addEventListener('DOMContentLoaded', function() {
    // Load saved theme
    const savedTheme = localStorage.getItem('jobpanel-theme') || 'dark';
    setTheme(savedTheme);
    
    // Listen for NUI messages
    window.addEventListener('message', handleNUIMessage);
    
    // Close on escape
    document.addEventListener('keydown', function(e) {
        if (e.key === 'Escape') {
            const openModals = document.querySelectorAll('.modal-overlay:not(.hidden)');
            if (openModals.length > 0) {
                openModals.forEach(function(modal) {
                    modal.classList.add('hidden');
                });
            } else {
                closePanel();
            }
        }
    });
    
    // Setup filter tabs
    setupFilterTabs();
    
    // Initialize loading animation
    simulateLoading();
});

// ===== Setup Functions =====
function setupFilterTabs() {
    // Employee filter tabs
    const filterTabs = document.querySelectorAll('.filter-tab');
    filterTabs.forEach(function(tab) {
        tab.addEventListener('click', function(e) {
            const filter = e.target.dataset.filter;
            filterTabs.forEach(function(t) { t.classList.remove('active'); });
            e.target.classList.add('active');
            filterEmployeesByStatus(filter);
        });
    });
    
    // Transaction filter buttons
    const filterBtns = document.querySelectorAll('.filter-btn');
    filterBtns.forEach(function(btn) {
        btn.addEventListener('click', function(e) {
            const filter = e.target.dataset.filter;
            filterBtns.forEach(function(b) { b.classList.remove('active'); });
            e.target.classList.add('active');
            filterTransactions(filter);
        });
    });
}

// ===== Loading Screen =====
function simulateLoading() {
    const loadingScreen = document.getElementById('loadingScreen');
    if (!loadingScreen) return;
    
    setTimeout(function() {
        loadingScreen.classList.add('hidden');
    }, 2500);
}

function showLoading() {
    if (isLoading) return;
    isLoading = true;
    
    const loadingScreen = document.getElementById('loadingScreen');
    if (!loadingScreen) return;
    
    loadingScreen.classList.remove('hidden');
    
    const progressBar = loadingScreen.querySelector('.loader-progress');
    if (progressBar) {
        progressBar.style.animation = 'none';
        void progressBar.offsetHeight;
        progressBar.style.animation = 'loading 1.5s ease-in-out forwards';
    }
}

function hideLoading() {
    const loadingScreen = document.getElementById('loadingScreen');
    if (!loadingScreen) return;
    
    setTimeout(function() {
        loadingScreen.classList.add('hidden');
        isLoading = false;
    }, 500);
}

// ===== NUI Message Handler =====
function handleNUIMessage(event) {
    const data = event.data;
    if (!data || !data.action) return;
    
    switch (data.action) {
        case 'openPanel':
            openPanel(data);
            break;
        case 'updateEmployees':
            if (data.employees) {
                updateEmployees(data.employees);
            }
            break;
        case 'updateFinances':
            if (data.finances) {
                updateFinances(data.finances);
            }
            break;
        case 'updateNearbyPlayers':
            if (data.players) {
                updateNearbyPlayers(data.players);
            }
            break;
        case 'notification':
            showToast(data.type || 'info', data.title || getToastTitle(data.type), data.message || '');
            break;
        case 'close':
            const app = document.getElementById('app');
            if (app) app.classList.add('hidden');
            break;
    }
}

// ===== Panel Control =====
function openPanel(data) {
    if (!data) return;
    
    // Merge data safely
    panelData.job = data.job || '';
    panelData.grade = data.grade || 0;
    panelData.permissions = data.permissions || {};
    panelData.employees = data.employees || [];
    panelData.ranks = data.ranks || [];
    panelData.finances = data.finances || { balance: 0, transactions: [] };
    panelData.vehicles = data.vehicles || [];
    panelData.items = data.items || [];
    panelData.logs = data.logs || [];
    panelData.branding = data.branding || { title: 'Elias Developments', subtitle: 'Job Management System' };
    
    showLoading();
    
    setTimeout(function() {
        // Update UI
        updateBranding(panelData.branding);
        updateJobInfo(data);
        updateUserInfo(data);
        applyPermissions(panelData.permissions);
        
        // Load sections
        loadDashboard();
        loadEmployees();
        loadSalaries();
        loadRanks();
        loadFinances();
        loadVehicles();
        loadItems();
        loadLogs();
        updateCart();
        
        // Show panel
        const app = document.getElementById('app');
        if (app) {
            app.classList.remove('hidden');
        }
        
        // Animate counters
        setTimeout(animateCounters, 300);
        
        hideLoading();
    }, 1000);
}

function closePanel() {
    const app = document.getElementById('app');
    if (!app) return;
    
    app.style.animation = 'fadeOutScale 0.3s ease forwards';
    
    setTimeout(function() {
        app.classList.add('hidden');
        app.style.animation = '';
        
        sendToServer('closePanel', {});
    }, 300);
}

// ===== Server Communication =====
function sendToServer(endpoint, data) {
    try {
        fetch('https://' + getResourceName() + '/' + endpoint, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(data || {})
        }).catch(function(err) {
            console.log('[JobPanel] Fetch error:', err);
        });
    } catch (e) {
        console.log('[JobPanel] Error:', e);
    }
}

function getResourceName() {
    if (window.GetParentResourceName) {
        return window.GetParentResourceName();
    }
    return 'jobpanel';
}

// ===== Theme System =====
function toggleTheme() {
    const newTheme = currentTheme === 'dark' ? 'light' : 'dark';
    setTheme(newTheme);
}

function setTheme(theme) {
    currentTheme = theme;
    document.documentElement.setAttribute('data-theme', theme);
    
    try {
        localStorage.setItem('jobpanel-theme', theme);
    } catch (e) {}
    
    const themeLabel = document.getElementById('themeLabel');
    if (themeLabel) {
        themeLabel.textContent = theme === 'dark' ? 'Mörkt läge' : 'Ljust läge';
    }
    
    const toggle = document.getElementById('themeToggle');
    if (toggle) {
        toggle.style.transform = 'scale(0.9)';
        setTimeout(function() {
            toggle.style.transform = 'scale(1)';
        }, 150);
    }
}

// ===== Update Functions =====
function updateBranding(branding) {
    if (!branding) return;
    
    const brandTitle = document.querySelector('.brand-title');
    if (brandTitle) {
        brandTitle.textContent = branding.title || 'Elias Developments';
    }
    
    const brandSubtitle = document.querySelector('.brand-subtitle');
    if (brandSubtitle) {
        brandSubtitle.textContent = branding.subtitle || 'Job Management';
    }
}

function updateJobInfo(data) {
    const jobName = document.getElementById('jobName');
    const jobRank = document.getElementById('jobRank');
    
    if (jobName) jobName.textContent = formatJobName(data.job);
    if (jobRank) jobRank.textContent = data.rankName || 'Rank';
}

function updateUserInfo(data) {
    const userName = document.getElementById('userName');
    const userRole = document.getElementById('userRole');
    const userAvatar = document.getElementById('userAvatar');
    
    if (userName) userName.textContent = data.playerName || 'Användare';
    if (userRole) userRole.textContent = data.rankName || 'Anställd';
    if (userAvatar) userAvatar.innerHTML = '<span>' + getInitials(data.playerName) + '</span>';
}

// ===== Permissions =====
function applyPermissions(permissions) {
    if (!permissions) permissions = {};
    
    const navMap = {
        'nav-employees': permissions.canViewEmployees !== false,
        'nav-salaries': !!permissions.canEditSalaries,
        'nav-ranks': !!permissions.canManageRanks,
        'nav-finances': !!permissions.canViewFinances,
        'nav-vehicles': !!permissions.canOrderVehicles,
        'nav-items': !!permissions.canOrderItems,
        'nav-logs': !!permissions.canViewLogs
    };
    
    for (var id in navMap) {
        var btn = document.getElementById(id);
        if (btn) {
            if (navMap[id]) {
                btn.classList.remove('disabled');
            } else {
                btn.classList.add('disabled');
            }
        }
    }
    
    // Action buttons
    var hireBtn = document.getElementById('btn-hire');
    var quickHire = document.getElementById('quickHire');
    var fireBtn = document.getElementById('btn-fire-employee');
    
    if (!permissions.canHire) {
        if (hireBtn) hireBtn.style.display = 'none';
        if (quickHire) quickHire.style.display = 'none';
    } else {
        if (hireBtn) hireBtn.style.display = '';
        if (quickHire) quickHire.style.display = '';
    }
    
    if (!permissions.canFire && fireBtn) {
        fireBtn.style.display = 'none';
    }
}

// ===== Tab Navigation =====
function switchTab(tabName) {
    var permissions = panelData.permissions || {};
    
    var tabPerms = {
        'employees': permissions.canViewEmployees !== false,
        'salaries': !!permissions.canEditSalaries,
        'ranks': !!permissions.canManageRanks,
        'finances': !!permissions.canViewFinances,
        'vehicles': !!permissions.canOrderVehicles,
        'items': !!permissions.canOrderItems,
        'logs': !!permissions.canViewLogs,
        'dashboard': true
    };
    
    if (!tabPerms[tabName]) {
        showToast('error', 'Ingen Behörighet', 'Du har inte tillgång till denna sida');
        return;
    }
    
    // Update nav
    var navItems = document.querySelectorAll('.nav-item');
    navItems.forEach(function(btn) {
        btn.classList.remove('active');
    });
    
    var activeBtn = document.querySelector('[data-tab="' + tabName + '"]');
    if (activeBtn) {
        activeBtn.classList.add('active');
    }
    
    // Update content
    var tabs = document.querySelectorAll('.tab-content');
    tabs.forEach(function(tab) {
        tab.classList.remove('active');
    });
    
    var targetTab = document.getElementById('tab-' + tabName);
    if (targetTab) {
        targetTab.classList.add('active');
        animateTabContent(targetTab);
    }
    
    updatePageTitle(tabName);
}

function animateTabContent(tab) {
    var elements = tab.querySelectorAll('.animate-in');
    elements.forEach(function(el, index) {
        el.style.opacity = '0';
        el.style.animation = 'none';
        void el.offsetHeight;
        el.style.animation = 'slideUp 0.5s ease forwards';
        el.style.animationDelay = (index * 0.1) + 's';
    });
}

function updatePageTitle(tabName) {
    var titles = {
        'dashboard': { title: 'Översikt', subtitle: 'Välkommen tillbaka! Här är en överblick av ditt jobb.' },
        'employees': { title: 'Personal', subtitle: 'Hantera anställda och deras information.' },
        'salaries': { title: 'Löner', subtitle: 'Hantera löner och bonusar för personalen.' },
        'ranks': { title: 'Ranker', subtitle: 'Konfigurera ranker och behörigheter.' },
        'finances': { title: 'Ekonomi', subtitle: 'Överblick av företagets ekonomi.' },
        'vehicles': { title: 'Fordon', subtitle: 'Beställ och hantera företagsfordon.' },
        'items': { title: 'Utrustning', subtitle: 'Beställ utrustning och material.' },
        'logs': { title: 'Aktivitetslogg', subtitle: 'Se all aktivitet i organisationen.' }
    };
    
    var info = titles[tabName] || titles['dashboard'];
    
    var pageTitle = document.getElementById('pageTitle');
    var pageSubtitle = document.getElementById('pageSubtitle');
    
    if (pageTitle) pageTitle.textContent = info.title;
    if (pageSubtitle) pageSubtitle.textContent = info.subtitle;
}

// ===== Dashboard =====
function loadDashboard() {
    var employees = panelData.employees || [];
    var totalEmployees = employees.length;
    var onlineEmployees = employees.filter(function(e) { return e.online; }).length;
    var balance = (panelData.finances && panelData.finances.balance) || 0;
    var totalHours = calculateTotalHours();
    
    // Stats
    var statTotal = document.getElementById('statTotalEmployees');
    var statOnline = document.getElementById('statOnlineEmployees');
    var statBalance = document.getElementById('statBalance');
    var statHours = document.getElementById('statHours');
    
    if (statTotal) {
        statTotal.dataset.target = totalEmployees;
        statTotal.textContent = '0';
    }
    if (statOnline) {
        statOnline.dataset.target = onlineEmployees;
        statOnline.textContent = '0';
    }
    if (statBalance) statBalance.textContent = formatMoney(balance);
    if (statHours) statHours.textContent = totalHours + 'h';
    
    // Badges
    var employeeCount = document.getElementById('employeeCount');
    var onlineCountBadge = document.getElementById('onlineCountBadge');
    
    if (employeeCount) employeeCount.textContent = totalEmployees;
    if (onlineCountBadge) onlineCountBadge.textContent = onlineEmployees;
    
    loadRecentActivity();
    loadOnlineStaff();
}

function animateCounters() {
    var counters = document.querySelectorAll('.counter');
    
    counters.forEach(function(counter) {
        var target = parseInt(counter.dataset.target) || 0;
        var duration = 1500;
        var startTime = null;
        
        function updateCounter(timestamp) {
            if (!startTime) startTime = timestamp;
            var progress = Math.min((timestamp - startTime) / duration, 1);
            var current = Math.floor(progress * target);
            counter.textContent = current;
            
            if (progress < 1) {
                requestAnimationFrame(updateCounter);
            } else {
                counter.textContent = target;
            }
        }
        
        requestAnimationFrame(updateCounter);
    });
}

function loadRecentActivity() {
    var container = document.getElementById('recentActivity');
    if (!container) return;
    
    var logs = (panelData.logs || []).slice(0, 5);
    
    if (logs.length === 0) {
        container.innerHTML = '<div class="empty-state"><i class="fas fa-clock-rotate-left"></i><p>Ingen aktivitet att visa</p></div>';
        return;
    }
    
    var html = '';
    logs.forEach(function(log, index) {
        html += '<div class="activity-item" style="animation: slideUp 0.3s ease forwards; animation-delay: ' + (index * 0.1) + 's; opacity: 0;">' +
            '<div class="activity-icon ' + sanitize(log.type) + '">' +
            '<i class="fas ' + getActivityIcon(log.type) + '"></i>' +
            '</div>' +
            '<div class="activity-content">' +
            '<span class="activity-text">' + sanitize(log.message) + '</span>' +
            '<span class="activity-time">' + formatTime(log.timestamp) + '</span>' +
            '</div>' +
            '</div>';
    });
    
    container.innerHTML = html;
}

function loadOnlineStaff() {
    var container = document.getElementById('onlineStaffList');
    if (!container) return;
    
    var online = (panelData.employees || []).filter(function(e) { return e.online; });
    
    if (online.length === 0) {
        container.innerHTML = '<div class="empty-state"><i class="fas fa-users-slash"></i><p>Ingen personal online</p></div>';
        return;
    }
    
    var html = '';
    online.forEach(function(emp, index) {
        html += '<div class="online-staff-item" style="animation: slideUp 0.3s ease forwards; animation-delay: ' + (index * 0.1) + 's; opacity: 0;">' +
            '<div class="staff-avatar">' + getInitials(emp.name) + '</div>' +
            '<div class="staff-info">' +
            '<span class="staff-name">' + sanitize(emp.name) + '</span>' +
            '<span class="staff-rank">' + sanitize(emp.rankName) + '</span>' +
            '</div>' +
            '<div class="staff-status"></div>' +
            '</div>';
    });
    
    container.innerHTML = html;
}

// ===== Employees =====
function loadEmployees() {
    var container = document.getElementById('employeesGrid');
    if (!container) return;
    
    var employees = panelData.employees || [];
    
    if (employees.length === 0) {
        container.innerHTML = '<div class="empty-state full-width"><i class="fas fa-users"></i><p>Inga anställda hittades</p></div>';
        return;
    }
    
    var html = '';
    employees.forEach(function(emp, index) {
        html += '<div class="employee-card" data-id="' + sanitize(emp.identifier) + '" style="animation: slideUp 0.4s ease forwards; animation-delay: ' + (index * 0.05) + 's; opacity: 0;">' +
            '<div class="employee-card-header">' +
            '<div class="employee-avatar">' +
            getInitials(emp.name) +
            '<div class="employee-status-dot ' + (emp.online ? 'online' : 'offline') + '"></div>' +
            '</div>' +
            '<div class="employee-info">' +
            '<div class="employee-name">' + sanitize(emp.name) + '</div>' +
            '<span class="employee-rank-badge">' + sanitize(emp.rankName) + '</span>' +
            '</div>' +
            '</div>' +
            '<div class="employee-card-body">' +
            '<div class="employee-stat">' +
            '<span class="employee-stat-label">Lön</span>' +
            '<span class="employee-stat-value salary">' + formatMoney(emp.salary) + '</span>' +
            '</div>' +
            '<div class="employee-stat">' +
            '<span class="employee-stat-label">Timmar</span>' +
            '<span class="employee-stat-value">' + (emp.hours || 0) + 'h</span>' +
            '</div>' +
            '</div>' +
            '</div>';
    });
    
    container.innerHTML = html;
    
    // Add click handlers
    var cards = container.querySelectorAll('.employee-card');
    cards.forEach(function(card) {
        card.addEventListener('click', function() {
            var id = this.dataset.id;
            if (id) editEmployee(id);
        });
    });
}

function filterEmployees() {
    var search = document.getElementById('employeeSearch');
    if (!search) return;
    
    var searchValue = search.value.toLowerCase();
    var cards = document.querySelectorAll('.employee-card');
    
    cards.forEach(function(card) {
        var name = card.querySelector('.employee-name');
        var rank = card.querySelector('.employee-rank-badge');
        var nameText = name ? name.textContent.toLowerCase() : '';
        var rankText = rank ? rank.textContent.toLowerCase() : '';
        
        if (nameText.indexOf(searchValue) !== -1 || rankText.indexOf(searchValue) !== -1) {
            card.style.display = '';
        } else {
            card.style.display = 'none';
        }
    });
}

function filterEmployeesByStatus(status) {
    var cards = document.querySelectorAll('.employee-card');
    
    cards.forEach(function(card) {
        var dot = card.querySelector('.employee-status-dot');
        var isOnline = dot && dot.classList.contains('online');
        
        if (status === 'all') {
            card.style.display = '';
        } else if (status === 'online' && isOnline) {
            card.style.display = '';
        } else if (status === 'offline' && !isOnline) {
            card.style.display = '';
        } else {
            card.style.display = 'none';
        }
    });
}

function editEmployee(identifier) {
    var employee = null;
    var employees = panelData.employees || [];
    
    for (var i = 0; i < employees.length; i++) {
        if (employees[i].identifier === identifier) {
            employee = employees[i];
            break;
        }
    }
    
    if (!employee) return;
    
    document.getElementById('editEmployeeId').value = identifier;
    document.getElementById('editEmployeeName').value = employee.name || '';
    document.getElementById('editEmployeeSalary').value = employee.individualSalary || '';
    
    var avatar = document.getElementById('editEmployeeAvatar');
    if (avatar) avatar.textContent = getInitials(employee.name);
    
    // Populate rank dropdown
    var rankSelect = document.getElementById('editEmployeeRank');
    if (rankSelect) {
        var html = '';
        (panelData.ranks || []).forEach(function(rank) {
            var selected = rank.grade === employee.grade ? ' selected' : '';
            html += '<option value="' + rank.grade + '"' + selected + '>' + sanitize(rank.name) + '</option>';
        });
        rankSelect.innerHTML = html;
    }
    
    openModal('editEmployeeModal');
}

function saveEmployeeChanges() {
    var identifier = document.getElementById('editEmployeeId').value;
    var gradeEl = document.getElementById('editEmployeeRank');
    var salaryEl = document.getElementById('editEmployeeSalary');
    
    var grade = gradeEl ? parseInt(gradeEl.value) : 0;
    var salary = salaryEl && salaryEl.value ? parseInt(salaryEl.value) : null;
    
    sendToServer('updateEmployee', {
        identifier: identifier,
        grade: grade,
        individualSalary: salary
    });
    
    closeModal('editEmployeeModal');
    showToast('success', 'Sparad', 'Ändringar har sparats');
}

function fireEmployee() {
    var identifier = document.getElementById('editEmployeeId').value;
    var nameEl = document.getElementById('editEmployeeName');
    var employeeName = nameEl ? nameEl.value : 'denna person';
    
    showConfirmModal(
        'Avskeda Anställd',
        'Är du säker på att du vill avskeda ' + employeeName + '?',
        'Avskeda',
        function() {
            sendToServer('fireEmployee', { identifier: identifier });
            closeModal('editEmployeeModal');
            showToast('success', 'Avskedad', 'Personen har blivit avskedad');
        }
    );
}

// ===== Hiring =====
function openHireModal() {
    selectedPlayer = null;
    
    var searchInput = document.getElementById('hirePlayerSearch');
    if (searchInput) searchInput.value = '';
    
    // Populate rank dropdown
    var rankSelect = document.getElementById('hireRank');
    if (rankSelect) {
        var html = '';
        (panelData.ranks || []).forEach(function(rank) {
            html += '<option value="' + rank.grade + '">' + sanitize(rank.name) + '</option>';
        });
        rankSelect.innerHTML = html;
    }
    
    // Request nearby players
    sendToServer('getNearbyPlayers', {});
    
    openModal('hireModal');
}

function updateNearbyPlayers(players) {
    var container = document.getElementById('nearbyPlayersList');
    if (!container) return;
    
    if (!players || players.length === 0) {
        container.innerHTML = '<div class="empty-state small"><p>Inga spelare i närheten</p></div>';
        return;
    }
    
    var html = '';
    players.forEach(function(player) {
        var selectedClass = selectedPlayer === player.id ? ' selected' : '';
        html += '<div class="nearby-player-item' + selectedClass + '" data-id="' + player.id + '" data-name="' + sanitize(player.name) + '">' +
            '<div class="nearby-player-avatar">' + getInitials(player.name) + '</div>' +
            '<div class="nearby-player-info">' +
            '<div class="nearby-player-name">' + sanitize(player.name) + '</div>' +
            '<div class="nearby-player-id">ID: ' + player.id + '</div>' +
            '</div>' +
            '</div>';
    });
    
    container.innerHTML = html;
    
    // Add click handlers
    var items = container.querySelectorAll('.nearby-player-item');
    items.forEach(function(item) {
        item.addEventListener('click', function() {
            var id = parseInt(this.dataset.id);
            var name = this.dataset.name;
            selectPlayerItem(id, name, this);
        });
    });
}

function selectPlayerItem(id, name, element) {
    selectedPlayer = id;
    
    var searchInput = document.getElementById('hirePlayerSearch');
    if (searchInput) searchInput.value = name;
    
    // Update visual selection
    var items = document.querySelectorAll('.nearby-player-item');
    items.forEach(function(item) {
        item.classList.remove('selected');
    });
    
    if (element) {
        element.classList.add('selected');
    }
}

function hirePlayer() {
    var searchInput = document.getElementById('hirePlayerSearch');
    var gradeSelect = document.getElementById('hireRank');
    
    var playerInput = searchInput ? searchInput.value : '';
    var grade = gradeSelect ? parseInt(gradeSelect.value) : 0;
    
    if (!selectedPlayer && !playerInput) {
        showToast('error', 'Fel', 'Välj en spelare att anställa');
        return;
    }
    
    var playerId = selectedPlayer || parseInt(playerInput);
    
    sendToServer('hirePlayer', {
        playerId: playerId,
        grade: grade
    });
    
    closeModal('hireModal');
    showToast('success', 'Anställd', 'Spelaren har blivit anställd');
}

// ===== Salaries =====
function loadSalaries() {
    var rankContainer = document.getElementById('rankSalariesGrid');
    if (rankContainer) {
        var html = '';
        (panelData.ranks || []).forEach(function(rank, index) {
            html += '<div class="salary-card" style="animation: slideUp 0.4s ease forwards; animation-delay: ' + (index * 0.05) + 's; opacity: 0;">' +
                '<div class="salary-card-header">' +
                '<div class="salary-rank-info">' +
                '<div class="salary-rank-badge">' + rank.grade + '</div>' +
                '<span class="salary-rank-name">' + sanitize(rank.name) + '</span>' +
                '</div>' +
                '</div>' +
                '<div class="salary-input-group">' +
                '<span class="input-prefix">$</span>' +
                '<input type="number" class="salary-input" value="' + (rank.salary || 0) + '" data-grade="' + rank.grade + '">' +
                '</div>' +
                '</div>';
        });
        rankContainer.innerHTML = html;
        
        // Add change handlers
        var inputs = rankContainer.querySelectorAll('.salary-input');
        inputs.forEach(function(input) {
            input.addEventListener('change', function() {
                this.classList.add('changed');
            });
        });
    }
    
    // Bonus dropdown
    var bonusSelect = document.getElementById('bonusEmployee');
    if (bonusSelect) {
        var html = '<option value="">Välj mottagare...</option>';
        (panelData.employees || []).forEach(function(emp) {
            html += '<option value="' + sanitize(emp.identifier) + '">' + sanitize(emp.name) + '</option>';
        });
        bonusSelect.innerHTML = html;
    }
}

function saveAllSalaries() {
    var salaries = {};
    var inputs = document.querySelectorAll('#rankSalariesGrid .salary-input');
    
    inputs.forEach(function(input) {
        var grade = input.dataset.grade;
        salaries[grade] = parseInt(input.value) || 0;
        input.classList.remove('changed');
    });
    
    sendToServer('updateSalaries', { salaries: salaries });
    showToast('success', 'Sparade', 'Alla löner har uppdaterats');
}

function giveBonus() {
    var employeeEl = document.getElementById('bonusEmployee');
    var amountEl = document.getElementById('bonusAmount');
    var reasonEl = document.getElementById('bonusReason');
    
    var employee = employeeEl ? employeeEl.value : '';
    var amount = amountEl ? parseInt(amountEl.value) : 0;
    var reason = reasonEl ? reasonEl.value : '';
    
    if (!employee) {
        showToast('error', 'Fel', 'Välj en mottagare');
        return;
    }
    
    if (!amount || amount <= 0) {
        showToast('error', 'Fel', 'Ange ett giltigt belopp');
        return;
    }
    
    sendToServer('giveBonus', {
        employee: employee,
        amount: amount,
        reason: reason
    });
    
    // Clear form
    if (employeeEl) employeeEl.value = '';
    if (amountEl) amountEl.value = '';
    if (reasonEl) reasonEl.value = '';
    
    showToast('success', 'Skickad', 'Bonus på ' + formatMoney(amount) + ' har skickats');
}

// ===== Ranks =====
function loadRanks() {
    var container = document.getElementById('ranksList');
    if (!container) return;
    
    var ranks = panelData.ranks || [];
    var canManage = panelData.permissions && panelData.permissions.canManageRanks;
    
    var html = '';
    ranks.forEach(function(rank, index) {
        html += '<div class="rank-item" style="animation: slideUp 0.4s ease forwards; animation-delay: ' + (index * 0.05) + 's; opacity: 0;">' +
            '<div class="rank-grade-badge">' + rank.grade + '</div>' +
            '<div class="rank-info">' +
            '<div class="rank-name">' + sanitize(rank.name) + '</div>' +
            '<div class="rank-salary">' + formatMoney(rank.salary) + '/dag</div>' +
            '</div>' +
            '<div class="rank-permissions-preview">' +
            renderPermissionIcons(rank.permissions) +
            '</div>' +
            '<button class="btn btn-secondary" data-grade="' + rank.grade + '"' + (canManage ? '' : ' disabled') + '>' +
            '<i class="fas fa-cog"></i> Redigera' +
            '</button>' +
            '</div>';
    });
    
    container.innerHTML = html;
    
    // Add click handlers
    var buttons = container.querySelectorAll('.btn');
    buttons.forEach(function(btn) {
        btn.addEventListener('click', function() {
            var grade = parseInt(this.dataset.grade);
            if (!isNaN(grade)) {
                editRankPermissions(grade);
            }
        });
    });
}

function renderPermissionIcons(permissions) {
    if (!permissions) return '';
    
    var icons = [
        { key: 'canHire', icon: 'fa-user-plus', title: 'Anställa' },
        { key: 'canFire', icon: 'fa-user-minus', title: 'Avskeda' },
        { key: 'canPromote', icon: 'fa-arrow-up', title: 'Befordra' },
        { key: 'canEditSalaries', icon: 'fa-dollar-sign', title: 'Löner' },
        { key: 'canViewFinances', icon: 'fa-chart-line', title: 'Ekonomi' }
    ];
    
    var html = '';
    icons.forEach(function(item) {
        var enabled = permissions[item.key] ? 'enabled' : 'disabled';
        html += '<div class="perm-icon ' + enabled + '" title="' + item.title + '">' +
            '<i class="fas ' + item.icon + '"></i>' +
            '</div>';
    });
    
    return html;
}

function editRankPermissions(grade) {
    var rank = null;
    var ranks = panelData.ranks || [];
    
    for (var i = 0; i < ranks.length; i++) {
        if (ranks[i].grade === grade) {
            rank = ranks[i];
            break;
        }
    }
    
    if (!rank) return;
    
    document.getElementById('editRankGrade').value = grade;
    document.getElementById('editRankName').value = rank.name || '';
    document.getElementById('editRankSalary').value = rank.salary || 0;
    
    var permissions = rank.permissions || {};
    var permGrid = document.getElementById('permissionsGrid');
    
    var permissionsList = [
        { key: 'canViewPanel', label: 'Visa Jobpanel' },
        { key: 'canViewEmployees', label: 'Visa Personal' },
        { key: 'canViewFinances', label: 'Visa Ekonomi' },
        { key: 'canHire', label: 'Anställa Personal' },
        { key: 'canFire', label: 'Avskeda Personal' },
        { key: 'canPromote', label: 'Befordra/Degradera' },
        { key: 'canEditSalaries', label: 'Ändra Löner' },
        { key: 'canOrderVehicles', label: 'Beställa Fordon' },
        { key: 'canOrderItems', label: 'Beställa Utrustning' },
        { key: 'canViewLogs', label: 'Visa Loggar' },
        { key: 'canManageRanks', label: 'Hantera Ranker' }
    ];
    
    var html = '';
    permissionsList.forEach(function(perm) {
        var checked = permissions[perm.key] ? ' checked' : '';
        html += '<div class="permission-item">' +
            '<input type="checkbox" id="perm-' + perm.key + '"' + checked + '>' +
            '<label for="perm-' + perm.key + '">' + perm.label + '</label>' +
            '</div>';
    });
    
    permGrid.innerHTML = html;
    
    // Add click handlers for permission items
    var items = permGrid.querySelectorAll('.permission-item');
    items.forEach(function(item) {
        item.addEventListener('click', function(e) {
            if (e.target.tagName !== 'INPUT') {
                var checkbox = this.querySelector('input[type="checkbox"]');
                if (checkbox) {
                    checkbox.checked = !checkbox.checked;
                }
            }
        });
    });
    
    openModal('rankPermissionsModal');
}

function saveRankPermissions() {
    var gradeEl = document.getElementById('editRankGrade');
    var nameEl = document.getElementById('editRankName');
    var salaryEl = document.getElementById('editRankSalary');
    
    var grade = gradeEl ? parseInt(gradeEl.value) : 0;
    var name = nameEl ? nameEl.value : '';
    var salary = salaryEl ? parseInt(salaryEl.value) : 0;
    
    var permissions = {};
    var checkboxes = document.querySelectorAll('#permissionsGrid input[type="checkbox"]');
    checkboxes.forEach(function(checkbox) {
        var key = checkbox.id.replace('perm-', '');
        permissions[key] = checkbox.checked;
    });
    
    sendToServer('updateRankPermissions', {
        grade: grade,
        name: name,
        salary: salary,
        permissions: permissions
    });
    
    closeModal('rankPermissionsModal');
    showToast('success', 'Uppdaterad', 'Rank har uppdaterats');
}

// ===== Finances =====
function loadFinances() {
    var balanceEl = document.getElementById('financeBalance');
    if (balanceEl) {
        var balance = (panelData.finances && panelData.finances.balance) || 0;
        balanceEl.textContent = formatMoney(balance);
    }
    
    loadTransactions();
}

function loadTransactions() {
    var container = document.getElementById('transactionsList');
    if (!container) return;
    
    var transactions = (panelData.finances && panelData.finances.transactions) || [];
    
    if (transactions.length === 0) {
        container.innerHTML = '<div class="empty-state"><i class="fas fa-receipt"></i><p>Inga transaktioner</p></div>';
        return;
    }
    
    var html = '';
    transactions.forEach(function(tx) {
        var desc = tx.description || (tx.type === 'deposit' ? 'Insättning' : 'Uttag');
        var amountClass = tx.type === 'deposit' ? 'positive' : 'negative';
        var amountPrefix = tx.type === 'deposit' ? '+' : '-';
        var icon = tx.type === 'deposit' ? 'fa-arrow-down' : 'fa-arrow-up';
        
        html += '<div class="transaction-item" data-type="' + tx.type + '">' +
            '<div class="transaction-icon ' + tx.type + '">' +
            '<i class="fas ' + icon + '"></i>' +
            '</div>' +
            '<div class="transaction-info">' +
            '<div class="transaction-desc">' + sanitize(desc) + '</div>' +
            '<div class="transaction-meta">' + formatTime(tx.timestamp) + ' • ' + sanitize(tx.by || 'Okänd') + '</div>' +
            '</div>' +
            '<div class="transaction-amount ' + amountClass + '">' +
            amountPrefix + formatMoney(tx.amount) +
            '</div>' +
            '</div>';
    });
    
    container.innerHTML = html;
}

function filterTransactions(filter) {
    var items = document.querySelectorAll('.transaction-item');
    
    items.forEach(function(item) {
        if (filter === 'all' || item.dataset.type === filter) {
            item.style.display = '';
        } else {
            item.style.display = 'none';
        }
    });
}

function openDepositModal() {
    currentMoneyAction = 'deposit';
    
    var icon = document.getElementById('moneyModalIcon');
    if (icon) {
        icon.className = 'modal-icon green';
        icon.innerHTML = '<i class="fas fa-plus"></i>';
    }
    
    var title = document.getElementById('moneyModalTitle');
    var subtitle = document.getElementById('moneyModalSubtitle');
    
    if (title) title.textContent = 'Sätt In Pengar';
    if (subtitle) subtitle.textContent = 'Överför pengar till företagskassan';
    
    var amountEl = document.getElementById('moneyAmount');
    var reasonEl = document.getElementById('moneyReason');
    
    if (amountEl) amountEl.value = '';
    if (reasonEl) reasonEl.value = '';
    
    openModal('moneyModal');
}

function openWithdrawModal() {
    currentMoneyAction = 'withdraw';
    
    var icon = document.getElementById('moneyModalIcon');
    if (icon) {
        icon.className = 'modal-icon red';
        icon.innerHTML = '<i class="fas fa-minus"></i>';
    }
    
    var title = document.getElementById('moneyModalTitle');
    var subtitle = document.getElementById('moneyModalSubtitle');
    
    if (title) title.textContent = 'Ta Ut Pengar';
    if (subtitle) subtitle.textContent = 'Ta ut pengar från företagskassan';
    
    var amountEl = document.getElementById('moneyAmount');
    var reasonEl = document.getElementById('moneyReason');
    
    if (amountEl) amountEl.value = '';
    if (reasonEl) reasonEl.value = '';
    
    openModal('moneyModal');
}

function confirmMoneyAction() {
    var amountEl = document.getElementById('moneyAmount');
    var reasonEl = document.getElementById('moneyReason');
    
    var amount = amountEl ? parseInt(amountEl.value) : 0;
    var reason = reasonEl ? reasonEl.value : '';
    
    if (!amount || amount <= 0) {
        showToast('error', 'Fel', 'Ange ett giltigt belopp');
        return;
    }
    
    sendToServer('societyMoney', {
        action: currentMoneyAction,
        amount: amount,
        reason: reason
    });
    
    closeModal('moneyModal');
    
    var actionText = currentMoneyAction === 'deposit' ? 'Insättning' : 'Uttag';
    showToast('success', 'Genomförd', actionText + ' på ' + formatMoney(amount) + ' genomförd');
}

// ===== Vehicles =====
function loadVehicles() {
    var container = document.getElementById('vehiclesGrid');
    if (!container) return;
    
    var vehicles = panelData.vehicles || [];
    
    if (vehicles.length === 0) {
        container.innerHTML = '<div class="empty-state full-width"><i class="fas fa-car"></i><p>Inga fordon tillgängliga</p></div>';
        return;
    }
    
    var html = '';
    vehicles.forEach(function(vehicle, index) {
        html += '<div class="vehicle-card" style="animation: slideUp 0.4s ease forwards; animation-delay: ' + (index * 0.05) + 's; opacity: 0;">' +
            '<div class="vehicle-icon"><i class="fas fa-car-side"></i></div>' +
            '<div class="vehicle-name">' + sanitize(vehicle.label) + '</div>' +
            '<div class="vehicle-price">' + formatMoney(vehicle.price) + '</div>' +
            '<button class="btn btn-primary" data-model="' + sanitize(vehicle.model) + '" data-price="' + vehicle.price + '">' +
            '<i class="fas fa-shopping-cart"></i> Beställ' +
            '</button>' +
            '</div>';
    });
    
    container.innerHTML = html;
    
    // Add click handlers
    var buttons = container.querySelectorAll('.btn');
    buttons.forEach(function(btn) {
        btn.addEventListener('click', function() {
            var model = this.dataset.model;
            var price = parseInt(this.dataset.price);
            orderVehicle(model, price);
        });
    });
}

function orderVehicle(model, price) {
    showConfirmModal(
        'Beställ Fordon',
        'Vill du beställa detta fordon för ' + formatMoney(price) + '?',
        'Beställ',
        function() {
            sendToServer('orderVehicle', { model: model, price: price });
            showToast('success', 'Beställd', 'Fordon har beställts');
        }
    );
}

// ===== Items & Cart =====
function loadItems() {
    var container = document.getElementById('itemsGrid');
    if (!container) return;
    
    var items = panelData.items || [];
    
    if (items.length === 0) {
        container.innerHTML = '<div class="empty-state full-width"><i class="fas fa-boxes-stacked"></i><p>Ingen utrustning tillgänglig</p></div>';
        return;
    }
    
    var html = '';
    items.forEach(function(item, index) {
        html += '<div class="item-card" style="animation: slideUp 0.4s ease forwards; animation-delay: ' + (index * 0.05) + 's; opacity: 0;">' +
            '<div class="item-icon"><i class="fas fa-box"></i></div>' +
            '<div class="item-name">' + sanitize(item.label) + '</div>' +
            '<div class="item-price">' + formatMoney(item.price) + '</div>' +
            '<button class="btn btn-primary" data-item="' + sanitize(item.item) + '" data-label="' + sanitize(item.label) + '" data-price="' + item.price + '">' +
            '<i class="fas fa-plus"></i> Lägg till' +
            '</button>' +
            '</div>';
    });
    
    container.innerHTML = html;
    
    // Add click handlers
    var buttons = container.querySelectorAll('.btn');
    buttons.forEach(function(btn) {
        btn.addEventListener('click', function() {
            var itemId = this.dataset.item;
            var label = this.dataset.label;
            var price = parseInt(this.dataset.price);
            addToCart(itemId, label, price);
        });
    });
}

function addToCart(item, label, price) {
    var existing = null;
    for (var i = 0; i < cart.length; i++) {
        if (cart[i].item === item) {
            existing = cart[i];
            break;
        }
    }
    
    if (existing) {
        existing.quantity++;
    } else {
        cart.push({ item: item, label: label, price: price, quantity: 1 });
    }
    
    updateCart();
    showToast('success', 'Tillagd', label + ' tillagd i varukorgen');
}

function updateCart() {
    var container = document.getElementById('cartItems');
    var countEl = document.getElementById('cartCount');
    var totalEl = document.getElementById('cartTotal');
    
    var totalItems = 0;
    var totalPrice = 0;
    
    cart.forEach(function(item) {
        totalItems += item.quantity;
        totalPrice += item.price * item.quantity;
    });
    
    if (countEl) countEl.textContent = totalItems;
    if (totalEl) totalEl.textContent = formatMoney(totalPrice);
    
    if (!container) return;
    
    if (cart.length === 0) {
        container.innerHTML = '<div class="cart-empty"><i class="fas fa-cart-shopping"></i><p>Varukorgen är tom</p></div>';
        return;
    }
    
    var html = '';
    cart.forEach(function(item, index) {
        html += '<div class="cart-item">' +
            '<div class="cart-item-info">' +
            '<span class="cart-item-qty">' + item.quantity + '</span>' +
            '<span class="cart-item-name">' + sanitize(item.label) + '</span>' +
            '</div>' +
            '<span class="cart-item-price">' + formatMoney(item.price * item.quantity) + '</span>' +
            '<button class="cart-item-remove" data-index="' + index + '">' +
            '<i class="fas fa-xmark"></i>' +
            '</button>' +
            '</div>';
    });
    
    container.innerHTML = html;
    
    // Add remove handlers
    var removeButtons = container.querySelectorAll('.cart-item-remove');
    removeButtons.forEach(function(btn) {
        btn.addEventListener('click', function() {
            var index = parseInt(this.dataset.index);
            removeFromCart(index);
        });
    });
}

function removeFromCart(index) {
    if (index < 0 || index >= cart.length) return;
    
    if (cart[index].quantity > 1) {
        cart[index].quantity--;
    } else {
        cart.splice(index, 1);
    }
    
    updateCart();
}

function placeOrder() {
    if (cart.length === 0) {
        showToast('error', 'Tom Varukorg', 'Lägg till produkter i varukorgen först');
        return;
    }
    
    var totalPrice = 0;
    cart.forEach(function(item) {
        totalPrice += item.price * item.quantity;
    });
    
    showConfirmModal(
        'Bekräfta Beställning',
        'Vill du beställa ' + cart.length + ' produkter för ' + formatMoney(totalPrice) + '?',
        'Beställ',
        function() {
            sendToServer('orderItems', { items: cart });
            cart = [];
            updateCart();
            showToast('success', 'Beställd', 'Din beställning har skickats');
        }
    );
}

// ===== Logs =====
function loadLogs() {
    var container = document.getElementById('logsTimeline');
    if (!container) return;
    
    var logs = panelData.logs || [];
    
    if (logs.length === 0) {
        container.innerHTML = '<div class="empty-state"><i class="fas fa-scroll"></i><p>Inga loggar att visa</p></div>';
        return;
    }
    
    var html = '';
    logs.forEach(function(log, index) {
        html += '<div class="log-item" data-type="' + sanitize(log.type) + '" style="animation: slideUp 0.3s ease forwards; animation-delay: ' + (index * 0.03) + 's; opacity: 0;">' +
            '<div class="log-icon ' + sanitize(log.type) + '">' +
            '<i class="fas ' + getActivityIcon(log.type) + '"></i>' +
            '</div>' +
            '<div class="log-content">' +
            '<div class="log-message">' + sanitize(log.message) + '</div>' +
            '<div class="log-meta">' + formatTime(log.timestamp) + ' • ' + sanitize(log.by || 'System') + '</div>' +
            '</div>' +
            '</div>';
    });
    
    container.innerHTML = html;
}

function filterLogs() {
    var filterEl = document.getElementById('logTypeFilter');
    var filter = filterEl ? filterEl.value : 'all';
    
    var items = document.querySelectorAll('.log-item');
    
    items.forEach(function(item) {
        if (filter === 'all' || item.dataset.type === filter) {
            item.style.display = '';
        } else {
            item.style.display = 'none';
        }
    });
}

// ===== Modals =====
function openModal(modalId) {
    var modal = document.getElementById(modalId);
    if (!modal) return;
    
    modal.classList.remove('hidden');
    
    var content = modal.querySelector('.modal');
    if (content) {
        content.style.animation = 'none';
        void content.offsetHeight;
        content.style.animation = 'modalSlide 0.3s ease forwards';
    }
}

function closeModal(modalId) {
    var modal = document.getElementById(modalId);
    if (!modal) return;
    
    var content = modal.querySelector('.modal');
    if (content) {
        content.style.animation = 'modalSlideOut 0.2s ease forwards';
        setTimeout(function() {
            modal.classList.add('hidden');
        }, 200);
    } else {
        modal.classList.add('hidden');
    }
}

function showConfirmModal(title, message, confirmText, callback) {
    var titleEl = document.getElementById('confirmModalTitle');
    var messageEl = document.getElementById('confirmModalMessage');
    var btnEl = document.getElementById('confirmModalBtn');
    
    if (titleEl) titleEl.textContent = title;
    if (messageEl) messageEl.textContent = message;
    if (btnEl) btnEl.innerHTML = '<i class="fas fa-check"></i> ' + confirmText;
    
    confirmCallback = callback;
    openModal('confirmModal');
}

function confirmAction() {
    if (confirmCallback) {
        confirmCallback();
        confirmCallback = null;
    }
    closeModal('confirmModal');
}

// ===== Toast Notifications =====
function showToast(type, title, message) {
    var container = document.getElementById('toastContainer');
    if (!container) return;
    
    var toast = document.createElement('div');
    toast.className = 'toast ' + type;
    
    var icons = {
        success: 'fa-check',
        error: 'fa-xmark',
        warning: 'fa-exclamation',
        info: 'fa-info'
    };
    
    var icon = icons[type] || icons.info;
    
    toast.innerHTML = '<div class="toast-icon"><i class="fas ' + icon + '"></i></div>' +
        '<div class="toast-content">' +
        '<div class="toast-title">' + sanitize(title) + '</div>' +
        '<div class="toast-message">' + sanitize(message) + '</div>' +
        '</div>' +
        '<button class="toast-close"><i class="fas fa-xmark"></i></button>';
    
    container.appendChild(toast);
    
    // Add close handler
    var closeBtn = toast.querySelector('.toast-close');
    if (closeBtn) {
        closeBtn.addEventListener('click', function() {
            removeToast(toast);
        });
    }
    
    // Auto remove
    setTimeout(function() {
        removeToast(toast);
    }, 5000);
}

function removeToast(toast) {
    if (!toast || !toast.parentElement) return;
    
    toast.classList.add('removing');
    setTimeout(function() {
        if (toast.parentElement) {
            toast.remove();
        }
    }, 300);
}

function getToastTitle(type) {
    var titles = {
        success: 'Lyckades',
        error: 'Fel',
        warning: 'Varning',
        info: 'Information'
    };
    return titles[type] || 'Meddelande';
}

// ===== Sidebar =====
function toggleSidebar() {
    var sidebar = document.querySelector('.sidebar');
    if (sidebar) {
        sidebar.classList.toggle('open');
    }
}

function toggleUserMenu() {
    showToast('info', 'Kommer Snart', 'Användarmenyn är under utveckling');
}

// ===== Refresh =====
function refreshData() {
    showToast('info', 'Uppdaterar', 'Hämtar senaste data...');
    sendToServer('refreshData', {});
}

function updateEmployees(employees) {
    panelData.employees = employees || [];
    loadEmployees();
    loadDashboard();
}

function updateFinances(finances) {
    panelData.finances = finances || { balance: 0, transactions: [] };
    loadFinances();
    loadDashboard();
}

// ===== Utility Functions =====
function sanitize(text) {
    if (text === null || text === undefined) return '';
    var str = String(text);
    return str
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;')
        .replace(/"/g, '&quot;')
        .replace(/'/g, '&#039;');
}

function formatMoney(amount) {
    if (amount === null || amount === undefined) return '$0';
    var num = parseInt(amount) || 0;
    return '$' + num.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ' ');
}

function formatJobName(job) {
    if (!job) return 'Okänt Jobb';
    var names = {
        'police': 'Polisen',
        'ambulance': 'Sjukvården',
        'mechanic': 'Mekanikerna',
        'taxi': 'Taxi',
        'realestate': 'Fastigheter'
    };
    return names[job] || job.charAt(0).toUpperCase() + job.slice(1);
}

function formatTime(timestamp) {
    if (!timestamp) return 'Okänt';
    
    var date;
    if (typeof timestamp === 'string') {
        date = new Date(timestamp);
    } else {
        date = new Date(timestamp);
    }
    
    if (isNaN(date.getTime())) return 'Okänt';
    
    var now = new Date();
    var diff = Math.floor((now - date) / 1000);
    
    if (diff < 60) return 'Just nu';
    if (diff < 3600) return Math.floor(diff / 60) + ' min sedan';
    if (diff < 86400) return Math.floor(diff / 3600) + ' tim sedan';
    if (diff < 604800) return Math.floor(diff / 86400) + ' dagar sedan';
    
    var months = ['jan', 'feb', 'mar', 'apr', 'maj', 'jun', 'jul', 'aug', 'sep', 'okt', 'nov', 'dec'];
    return date.getDate() + ' ' + months[date.getMonth()];
}

function getInitials(name) {
    if (!name) return '?';
    var parts = String(name).split(' ');
    var initials = '';
    for (var i = 0; i < Math.min(parts.length, 2); i++) {
        if (parts[i].length > 0) {
            initials += parts[i][0].toUpperCase();
        }
    }
    return initials || '?';
}

function getActivityIcon(type) {
    var icons = {
        'hire': 'fa-user-plus',
        'fire': 'fa-user-minus',
        'promote': 'fa-arrow-up',
        'salary': 'fa-dollar-sign',
        'finance': 'fa-wallet',
        'deposit': 'fa-arrow-down',
        'withdraw': 'fa-arrow-up'
    };
    return icons[type] || 'fa-circle-info';
}

function calculateTotalHours() {
    var total = 0;
    var employees = panelData.employees || [];
    for (var i = 0; i < employees.length; i++) {
        total += employees[i].hours || 0;
    }
    return total;
}

// ===== Add Extra CSS =====
(function() {
    var style = document.createElement('style');
    style.textContent = [
        '@keyframes modalSlideOut {',
        '    from { opacity: 1; transform: translateY(0) scale(1); }',
        '    to { opacity: 0; transform: translateY(-20px) scale(0.95); }',
        '}',
        '@keyframes fadeOutScale {',
        '    from { opacity: 1; transform: translate(-50%, -50%) scale(1); }',
        '    to { opacity: 0; transform: translate(-50%, -50%) scale(0.95); }',
        '}',
        '.empty-state {',
        '    display: flex;',
        '    flex-direction: column;',
        '    align-items: center;',
        '    justify-content: center;',
        '    padding: 40px 20px;',
        '    color: var(--text-muted);',
        '}',
        '.empty-state.small { padding: 20px; }',
        '.empty-state.full-width { grid-column: 1 / -1; }',
        '.empty-state i { font-size: 48px; margin-bottom: 16px; opacity: 0.5; }',
        '.empty-state.small i { font-size: 24px; margin-bottom: 8px; }',
        '.empty-state p { font-size: 0.9rem; }'
    ].join('\n');
    document.head.appendChild(style);
})();