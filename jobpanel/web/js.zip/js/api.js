// ===== Elias Developments - API Helper =====

const API = {
    /**
     * Send POST request to server
     */
    post: async function(endpoint, data = {}) {
        try {
            const response = await fetch(`https://${GetParentResourceName()}/${endpoint}`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify(data)
            });
            
            if (!response.ok) {
                throw new Error(`HTTP error! status: ${response.status}`);
            }
            
            const text = await response.text();
            
            // Try to parse as JSON, otherwise return text
            try {
                return JSON.parse(text);
            } catch {
                return text;
            }
        } catch (error) {
            console.error(`[JobPanel API] Error on ${endpoint}:`, error);
            return { success: false, error: error.message };
        }
    },
    
    // ===== Panel Actions =====
    closePanel: () => API.post('closePanel'),
    refreshData: () => API.post('refreshData'),
    
    // ===== Employee Actions =====
    getEmployees: () => API.post('getEmployees'),
    getNearbyPlayers: () => API.post('getNearbyPlayers'),
    hirePlayer: (playerId, grade) => API.post('hirePlayer', { playerId, grade }),
    fireEmployee: (identifier) => API.post('fireEmployee', { identifier }),
    updateEmployee: (data) => API.post('updateEmployee', data),
    
    // ===== Salary Actions =====
    updateSalaries: (salaries) => API.post('updateSalaries', { salaries }),
    giveBonus: (employee, amount, reason) => API.post('giveBonus', { employee, amount, reason }),
    removeIndividualSalary: (identifier) => API.post('removeIndividualSalary', { identifier }),
    
    // ===== Rank Actions =====
    updateRankPermissions: (data) => API.post('updateRankPermissions', data),
    
    // ===== Finance Actions =====
    societyMoney: (action, amount, reason) => API.post('societyMoney', { action, amount, reason }),
    getFinances: () => API.post('getFinances'),
    
    // ===== Order Actions =====
    orderVehicle: (model, price) => API.post('orderVehicle', { model, price }),
    orderItems: (items) => API.post('orderItems', { items }),
    
    // ===== Log Actions =====
    getLogs: (type, limit) => API.post('getLogs', { type, limit })
};

/**
 * Get parent resource name for NUI
 */
function GetParentResourceName() {
    return window.GetParentResourceName ? window.GetParentResourceName() : 'jobpanel';
}

/**
 * Debug mode - log all API calls
 */
const DEBUG_API = false;

if (DEBUG_API) {
    const originalPost = API.post;
    API.post = async function(endpoint, data) {
        console.log(`[JobPanel API] POST ${endpoint}`, data);
        const result = await originalPost(endpoint, data);
        console.log(`[JobPanel API] Response ${endpoint}`, result);
        return result;
    };
}

// ===== Event System =====
const EventBus = {
    events: {},
    
    on(event, callback) {
        if (!this.events[event]) {
            this.events[event] = [];
        }
        this.events[event].push(callback);
    },
    
    off(event, callback) {
        if (!this.events[event]) return;
        this.events[event] = this.events[event].filter(cb => cb !== callback);
    },
    
    emit(event, data) {
        if (!this.events[event]) return;
        this.events[event].forEach(callback => callback(data));
    }
};

// ===== Utility Exports =====
window.API = API;
window.EventBus = EventBus;